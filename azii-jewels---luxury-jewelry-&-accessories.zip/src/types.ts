export interface Product {
  id: string;
  name: string;
  category: 'WOMEN' | 'MEN' | 'UNISEX';
  price: number;
  originalPrice?: number;
  badge?: 'NEW' | '-30%' | '-20%' | 'HOT';
  rating: number;
  image: string;
  type: 'bracelet' | 'ring' | 'earrings' | 'pendant';
  isBestSeller?: boolean;
  isNewArrival?: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  image: string;
  author: string;
  commentsCount: number;
  date: string;
  excerpt: string;
}

export interface PopularCategory {
  id: string;
  title: string;
  subtitle: string;
  image: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
