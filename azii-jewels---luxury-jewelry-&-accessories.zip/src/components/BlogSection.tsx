import React from 'react';
import { User, MessageSquare, Calendar } from 'lucide-react';
import { BLOG_POSTS } from '../data/storeData';
import { DiamondIcon } from './DiamondIcon';

export const BlogSection: React.FC = () => {
  return (
    <section id="blog" className="w-full bg-[#121212] py-16 text-white font-['Jost',sans-serif]">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-[0.2em] text-white uppercase font-['Montserrat',sans-serif] mb-2">
            LATEST NEWS FROM THE BLOG
          </h2>

          <div className="flex justify-center my-2">
            <DiamondIcon className="w-3.5 h-3.5 text-white/80" />
          </div>

          <p className="text-xs text-neutral-400 leading-relaxed max-w-xl mx-auto mt-2">
            This unique jewelry is handcrafted on the beautiful island of Nantucket using fine silver and semi precious stones. View glasse fashion collection 2018 by Fanbong
          </p>
        </div>

        {/* 3 Blog Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {BLOG_POSTS.map((post) => (
            <article
              key={post.id}
              className="bg-[#181818] border border-neutral-800 hover:border-neutral-700 transition-all duration-300 flex flex-col group"
            >
              {/* Blog Image */}
              <div className="relative aspect-[4/3] overflow-hidden bg-neutral-900">
                <img
                  src={post.image}
                  alt={post.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-[0.9]"
                />
              </div>

              {/* Blog Content */}
              <div className="p-6 flex flex-col flex-grow justify-between text-center items-center">
                <div>
                  <h3 className="text-sm font-bold tracking-widest text-white uppercase font-['Montserrat',sans-serif] mb-3 group-hover:text-amber-200 transition-colors">
                    {post.title}
                  </h3>

                  {/* Meta Details */}
                  <div className="flex items-center justify-center space-x-4 text-[10px] text-neutral-400 uppercase tracking-wider mb-4 border-b border-neutral-800 pb-3 w-full">
                    <span className="flex items-center space-x-1">
                      <User className="w-3 h-3 text-neutral-500" />
                      <span>{post.author}</span>
                    </span>
                    <span>•</span>
                    <span className="flex items-center space-x-1">
                      <MessageSquare className="w-3 h-3 text-neutral-500" />
                      <span>{post.commentsCount} Comments</span>
                    </span>
                    <span>•</span>
                    <span className="flex items-center space-x-1">
                      <Calendar className="w-3 h-3 text-neutral-500" />
                      <span>{post.date}</span>
                    </span>
                  </div>

                  <p className="text-xs text-neutral-400 leading-relaxed font-light mb-6">
                    {post.excerpt}
                  </p>
                </div>

                <button className="px-6 py-2 text-[10px] font-bold tracking-[0.2em] text-white uppercase bg-neutral-900 border border-neutral-700 hover:bg-white hover:text-black hover:border-white transition-all duration-300">
                  READ MORE
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
