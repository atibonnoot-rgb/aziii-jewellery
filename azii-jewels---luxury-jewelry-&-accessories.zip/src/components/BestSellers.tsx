import React, { useState } from 'react';
import { ShoppingBag, Heart, Eye, ArrowRightLeft, Star } from 'lucide-react';
import { Product } from '../types';
import { BEST_SELLER_PRODUCTS } from '../data/storeData';
import { DiamondIcon } from './DiamondIcon';

interface BestSellersProps {
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  wishlistIds: string[];
}

export const BestSellers: React.FC<BestSellersProps> = ({
  onAddToCart,
  onToggleWishlist,
  onQuickView,
  wishlistIds,
}) => {
  const [activeTab, setActiveTab] = useState<'BRACELETS' | 'RINGS' | 'EARRINGS'>('BRACELETS');

  return (
    <section id="bestsellers" className="w-full bg-[#121212] py-16 text-white font-['Jost',sans-serif]">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-[0.2em] text-white uppercase font-['Montserrat',sans-serif] mb-2">
            BEST SELLERS
          </h2>
          
          <div className="flex justify-center my-2">
            <DiamondIcon className="w-3.5 h-3.5 text-white/80" />
          </div>

          <p className="text-xs text-neutral-400 leading-relaxed max-w-xl mx-auto mt-2">
            This unique jewelry is handcrafted on the beautiful island of Nantucket using fine silver and semi precious stones. View glasse fashion collection 2018 by Fanbong
          </p>

          {/* Filter Tabs */}
          <div className="flex justify-center space-x-3 mt-6">
            {(['BRACELETS', 'RINGS', 'EARRINGS'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-5 py-1.5 text-[11px] font-semibold tracking-[0.15em] uppercase rounded-full transition-all ${
                  activeTab === tab
                    ? 'bg-white text-black font-bold shadow-md'
                    : 'bg-transparent text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {BEST_SELLER_PRODUCTS.map((product) => {
            const isWishlisted = wishlistIds.includes(product.id);

            return (
              <div
                key={product.id}
                className="group bg-[#181818] border border-neutral-800 hover:border-neutral-700 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Image Container */}
                <div className="relative w-full aspect-square bg-white flex items-center justify-center overflow-hidden p-4">
                  {/* Badge */}
                  {product.badge && (
                    <div className="absolute top-3 left-3 z-10">
                      {product.badge === 'NEW' ? (
                        <span className="bg-black text-white text-[9px] font-bold px-2 py-0.5 tracking-wider uppercase">
                          NEW
                        </span>
                      ) : (
                        <span className="bg-black text-white text-[10px] font-bold w-9 h-9 rounded-full flex items-center justify-center">
                          {product.badge}
                        </span>
                      )}
                    </div>
                  )}

                  <img
                    src={product.image}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Hover Actions Bar */}
                  <div className="absolute bottom-0 inset-x-0 bg-black/80 backdrop-blur-sm py-2 px-4 flex items-center justify-center space-x-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button
                      onClick={() => onAddToCart(product)}
                      className="text-neutral-300 hover:text-white transition-colors p-1.5"
                      title="Add to Cart"
                    >
                      <ShoppingBag className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => onToggleWishlist(product)}
                      className={`transition-colors p-1.5 ${isWishlisted ? 'text-amber-400' : 'text-neutral-300 hover:text-white'}`}
                      title="Add to Wishlist"
                    >
                      <Heart className="w-4 h-4 fill-current" />
                    </button>

                    <button
                      className="text-neutral-300 hover:text-white transition-colors p-1.5"
                      title="Compare"
                    >
                      <ArrowRightLeft className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => onQuickView(product)}
                      className="text-neutral-300 hover:text-white transition-colors p-1.5"
                      title="Quick View"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Info Section */}
                <div className="p-4 flex flex-col flex-grow justify-between bg-[#181818]">
                  <div>
                    <span className="text-[10px] tracking-widest text-neutral-500 uppercase font-medium">
                      {product.category}
                    </span>
                    <h3 className="text-xs font-semibold tracking-wider text-neutral-200 mt-1 uppercase line-clamp-2 leading-snug group-hover:text-white transition-colors">
                      {product.name}
                    </h3>
                  </div>

                  <div className="mt-3">
                    <div className="flex items-center space-x-2 text-xs font-semibold">
                      <span className="text-white">${product.price.toFixed(2)}</span>
                      {product.originalPrice && (
                        <span className="text-neutral-500 line-through text-[11px]">
                          ${product.originalPrice.toFixed(2)}
                        </span>
                      )}
                    </div>

                    {/* Star rating */}
                    <div className="flex items-center space-x-1 mt-1 text-amber-400 text-[10px]">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                      ))}
                      <span className="text-neutral-400 text-[10px] ml-1">(5.0)</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
