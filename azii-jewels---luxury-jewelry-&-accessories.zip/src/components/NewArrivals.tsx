import React from 'react';
import { ShoppingBag, Heart, Eye, ArrowRightLeft, Star } from 'lucide-react';
import { Product } from '../types';
import { NEW_ARRIVALS_PRODUCTS } from '../data/storeData';
import { DiamondIcon } from './DiamondIcon';

interface NewArrivalsProps {
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  wishlistIds: string[];
}

export const NewArrivals: React.FC<NewArrivalsProps> = ({
  onAddToCart,
  onToggleWishlist,
  onQuickView,
  wishlistIds,
}) => {
  return (
    <section id="newarrivals" className="w-full bg-[#121212] py-16 text-white font-['Jost',sans-serif]">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-[0.2em] text-white uppercase font-['Montserrat',sans-serif] mb-2">
            NEW ARRIVALS
          </h2>

          <div className="flex justify-center my-2">
            <DiamondIcon className="w-3.5 h-3.5 text-white/80" />
          </div>

          <p className="text-xs text-neutral-400 leading-relaxed max-w-xl mx-auto mt-2">
            This unique jewelry is handcrafted on the beautiful island of Nantucket using fine silver and semi precious stones. View glasse fashion collection 2018 by Fanbong
          </p>
        </div>

        {/* 5-Column Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {NEW_ARRIVALS_PRODUCTS.map((product) => {
            const isWishlisted = wishlistIds.includes(product.id);

            return (
              <div
                key={product.id}
                className="group bg-[#181818] border border-neutral-800 hover:border-neutral-700 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Image Container */}
                <div className="relative w-full aspect-square bg-white flex items-center justify-center overflow-hidden p-4">
                  <img
                    src={product.image}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Hover Actions Bar */}
                  <div className="absolute bottom-0 inset-x-0 bg-black/80 backdrop-blur-sm py-2 px-2 flex items-center justify-center space-x-2.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button
                      onClick={() => onAddToCart(product)}
                      className="text-neutral-300 hover:text-white transition-colors p-1"
                      title="Add to Cart"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => onToggleWishlist(product)}
                      className={`transition-colors p-1 ${isWishlisted ? 'text-amber-400' : 'text-neutral-300 hover:text-white'}`}
                      title="Add to Wishlist"
                    >
                      <Heart className="w-3.5 h-3.5 fill-current" />
                    </button>

                    <button
                      className="text-neutral-300 hover:text-white transition-colors p-1"
                      title="Compare"
                    >
                      <ArrowRightLeft className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => onQuickView(product)}
                      className="text-neutral-300 hover:text-white transition-colors p-1"
                      title="Quick View"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Info Container */}
                <div className="p-3.5 flex flex-col flex-grow justify-between bg-[#181818]">
                  <div>
                    <span className="text-[9px] tracking-widest text-neutral-500 uppercase font-medium">
                      {product.category}
                    </span>
                    <h3 className="text-[11px] font-semibold tracking-wider text-neutral-200 mt-1 uppercase line-clamp-2 leading-tight group-hover:text-white transition-colors">
                      {product.name}
                    </h3>
                  </div>

                  <div className="mt-3">
                    <div className="text-xs font-semibold text-white">
                      ${product.price.toFixed(2)}
                    </div>

                    <div className="flex items-center space-x-1 mt-1 text-amber-400 text-[9px]">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                      ))}
                      <span className="text-neutral-400 text-[9px] ml-0.5">(5.0)</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
