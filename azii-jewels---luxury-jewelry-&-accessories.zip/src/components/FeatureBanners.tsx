import React from 'react';

export const FeatureBanners: React.FC = () => {
  const banners = [
    {
      title: 'BRACELETS',
      description: 'Lorem ipsum dolor sit amet conse ctetur adipiscing elit, sed do eiusmod',
      image: 'https://images.unsplash.com/photo-1611591475281-912f7166184a?auto=format&fit=crop&w=800&q=80',
      link: '#bestsellers'
    },
    {
      title: 'RINGS',
      description: 'Lorem ipsum dolor sit amet conse ctetur adipiscing elit, sed do eiusmod',
      image: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?auto=format&fit=crop&w=800&q=80',
      link: '#bestsellers'
    },
    {
      title: 'EARRINGS',
      description: 'Lorem ipsum dolor sit amet conse ctetur adipiscing elit, sed do eiusmod',
      image: 'https://images.unsplash.com/photo-1535632787350-4e68ef0ac584?auto=format&fit=crop&w=800&q=80',
      link: '#bestsellers'
    }
  ];

  return (
    <section className="w-full bg-[#121212] py-8">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6">
        {banners.map((item, index) => (
          <div
            key={index}
            className="group relative h-[360px] overflow-hidden bg-neutral-900 flex flex-col justify-end border border-neutral-800 hover:border-neutral-700 transition-all"
          >
            {/* Background Image */}
            <img
              src={item.image}
              alt={item.title}
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-[0.75] group-hover:brightness-[0.85]"
            />

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

            {/* Content Box */}
            <div className="relative z-10 p-6 text-center flex flex-col items-center">
              <h3 className="text-xl font-bold tracking-[0.2em] text-white uppercase font-['Montserrat',sans-serif] mb-2">
                {item.title}
              </h3>
              <p className="text-xs text-neutral-300 font-light max-w-xs leading-relaxed mb-4">
                {item.description}
              </p>
              <a
                href={item.link}
                className="text-xs font-semibold tracking-[0.2em] text-white uppercase border-b border-white/60 hover:border-white pb-0.5 hover:text-amber-200 transition-colors"
              >
                SHOP NOW
              </a>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
