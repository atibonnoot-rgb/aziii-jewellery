import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { POPULAR_CATEGORIES } from '../data/storeData';

export const PopularCategories: React.FC = () => {
  const [startIndex, setStartIndex] = useState(0);

  const prevCategory = () => {
    setStartIndex((prev) => (prev === 0 ? POPULAR_CATEGORIES.length - 1 : prev - 1));
  };

  const nextCategory = () => {
    setStartIndex((prev) => (prev === POPULAR_CATEGORIES.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="categories" className="w-full bg-[#121212] py-16 text-white font-['Jost',sans-serif] border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Title & Nav Arrows */}
        <div className="relative text-center mb-10">
          <h2 className="text-xl sm:text-2xl font-bold tracking-[0.2em] text-white uppercase font-['Montserrat',sans-serif]">
            POPULAR CATEGORIES
          </h2>

          <div className="absolute left-0 top-1/2 -translate-y-1/2 hidden sm:block">
            <button
              onClick={prevCategory}
              className="p-1.5 text-neutral-400 hover:text-white transition-colors"
              aria-label="Previous category"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>

          <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden sm:block">
            <button
              onClick={nextCategory}
              className="p-1.5 text-neutral-400 hover:text-white transition-colors"
              aria-label="Next category"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {POPULAR_CATEGORIES.map((cat) => (
            <div
              key={cat.id}
              className="bg-[#181818] border border-neutral-800 hover:border-neutral-700 p-8 flex flex-col items-center text-center group cursor-pointer transition-all duration-300"
            >
              {/* Circular/Square Thumbnail Image */}
              <div className="w-28 h-28 rounded-full overflow-hidden bg-white p-2 border border-neutral-700 mb-6 group-hover:border-white transition-colors">
                <img
                  src={cat.image}
                  alt={cat.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              <h3 className="text-sm font-bold tracking-[0.15em] text-white uppercase font-['Montserrat',sans-serif] mb-1">
                {cat.title}
              </h3>

              <p className="text-xs text-neutral-400 font-light tracking-wide">
                {cat.subtitle}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
