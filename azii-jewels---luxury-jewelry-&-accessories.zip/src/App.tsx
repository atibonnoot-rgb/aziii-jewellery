import React, { useState } from 'react';
import { Product, CartItem } from './types';
import { BEST_SELLER_PRODUCTS, NEW_ARRIVALS_PRODUCTS } from './data/storeData';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { FeatureBanners } from './components/FeatureBanners';
import { BestSellers } from './components/BestSellers';
import { NewArrivals } from './components/NewArrivals';
import { MiddleBanner } from './components/MiddleBanner';
import { BlogSection } from './components/BlogSection';
import { PopularCategories } from './components/PopularCategories';
import { Footer } from './components/Footer';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);

  const allProducts = [...BEST_SELLER_PRODUCTS, ...NEW_ARRIVALS_PRODUCTS];

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Wishlist operations
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      }
      return [...prev, product];
    });
  };

  const handleRemoveFromWishlist = (productId: string) => {
    setWishlist((prev) => prev.filter((p) => p.id !== productId));
  };

  const handleSearch = (query: string) => {
    if (!query) return;
    const found = allProducts.find((p) =>
      p.name.toLowerCase().includes(query.toLowerCase())
    );
    if (found) {
      setSelectedProduct(found);
    } else {
      alert(`No products found matching "${query}"`);
    }
  };

  return (
    <div className="min-h-screen bg-[#121212] text-white flex flex-col font-['Jost',sans-serif] selection:bg-amber-400 selection:text-black">
      {/* 1. Header */}
      <Header
        cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)}
        wishlistCount={wishlist.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onSearch={handleSearch}
      />

      <main className="flex-grow">
        {/* 2. Hero Banner Slider */}
        <HeroBanner />

        {/* 3. Feature Category Banners (Bracelets, Rings, Earrings) */}
        <FeatureBanners />

        {/* 4. Best Sellers Section */}
        <BestSellers
          onAddToCart={(p) => handleAddToCart(p, 1)}
          onToggleWishlist={handleToggleWishlist}
          onQuickView={setSelectedProduct}
          wishlistIds={wishlist.map((w) => w.id)}
        />

        {/* 5. New Arrivals Section */}
        <NewArrivals
          onAddToCart={(p) => handleAddToCart(p, 1)}
          onToggleWishlist={handleToggleWishlist}
          onQuickView={setSelectedProduct}
          wishlistIds={wishlist.map((w) => w.id)}
        />

        {/* 7. Middle Promotion Banner */}
        <MiddleBanner />

        {/* 8. Latest News From The Blog */}
        <BlogSection />

        {/* 9. Popular Categories Carousel */}
        <PopularCategories />
      </main>

      {/* 10. Footer */}
      <Footer />

      {/* Quick View Product Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onToggleWishlist={handleToggleWishlist}
        isWishlisted={selectedProduct ? wishlist.some((w) => w.id === selectedProduct.id) : false}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveFromCart}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistProducts={wishlist}
        onRemoveWishlist={handleRemoveFromWishlist}
        onAddToCart={(p) => handleAddToCart(p, 1)}
      />
    </div>
  );
}
